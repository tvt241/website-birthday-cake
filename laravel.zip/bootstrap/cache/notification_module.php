<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Notification\\Providers\\NotificationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Notification\\Providers\\NotificationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);