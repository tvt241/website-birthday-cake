<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Banner\\Providers\\BannerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Banner\\Providers\\BannerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);