<template>
    <footer class="footer mt-auto">
        <div class="copyright bg-white">
            <p>
                &copy; <span id="copy-year">2024</span> Copyright by <a
                    class="text-primary" href="http://www.iamabdus.com/" target="_blank">TVT</a>.
            </p>
        </div>
    </footer>
</template>