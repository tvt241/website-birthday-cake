import couponRouter from "./routers/couponRouter";

export default [
    ...couponRouter
];