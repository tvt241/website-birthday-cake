<template>
    <PageHeaderTitleComponent headerTitle="product-create">
    </PageHeaderTitleComponent>

    vào trang nauyf à 
</template>

<script setup>
    import PageHeaderTitleComponent from "~/Core/components/PageHeaderTitleComponent.vue";
</script>