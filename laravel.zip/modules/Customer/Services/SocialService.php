<?php

namespace Modules\Customer\Services;

use Modules\Customer\Enums\CustomerSocialEnum;
use Modules\Customer\Models\Customer;

class SocialService
{
    public function handleLoginWithSocial($info, $social)
    {

        
        return $user;
    }
}
