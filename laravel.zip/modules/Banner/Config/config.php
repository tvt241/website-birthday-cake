<?php

return [
    'name' => 'Banner'
];
