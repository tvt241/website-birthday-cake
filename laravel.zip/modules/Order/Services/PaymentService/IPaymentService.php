<?php
namespace Modules\Order\Services\PaymentService;

interface IPaymentService
{
    
}