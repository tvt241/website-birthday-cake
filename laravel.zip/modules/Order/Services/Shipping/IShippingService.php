<?php
namespace Modules\Order\Services\Shipping;

interface IShippingService
{

}