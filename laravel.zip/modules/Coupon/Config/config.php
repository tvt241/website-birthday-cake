<?php

return [
    'name' => 'Coupon'
];
