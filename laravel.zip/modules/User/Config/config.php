<?php

return [
    'name' => 'User'
];
